(function () {
  'use strict';

  const DATA = window.BAC_DATA;
  const SUBJECTS = DATA.subjects;
  const DRIVE = 'https://drive.google.com/file/d/';
  const DRIVE_DL = 'https://drive.google.com/uc?export=download&id=';

  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));

  const esc = (s) => String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

  const norm = (s) => String(s || '')
    .replace(/[\u064B-\u0652\u0640]/g, '')
    .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
    .toLowerCase().trim();

  const store = {
    get(k, d) { try { const v = localStorage.getItem('bacge_' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('bacge_' + k, JSON.stringify(v)); } catch (e) {} }
  };

  const DEFAULT_COEFF = {
    accounting: 6, economics: 3, law: 3, math: 3, 'hist-geo': 2,
    arabic: 3, french: 3, english: 2, islamics: 2, philo: 2, 'Tamaziɣt': 2
  };

  const State = {
    done: new Set(store.get('done', [])),
    favs: new Set(store.get('favs', [])),
    last: store.get('last', null),
    theme: store.get('theme', 'dark'),
    bacDate: store.get('date', '2027-06-06'),
    marks: store.get('marks', {}),
    coeffs: store.get('coeffs', DEFAULT_COEFF),
    profile: store.get('profile', null),
    viewer: null
  };

  /* ---------- index ---------- */
  const FILES = new Map();
  const ALL_IDS = [];

  function walk(node, sub, secName, crumb, path) {
    const ids = [];
    (node.f || []).forEach(function (f) {
      const rec = {
        id: f.id, t: f.t === 'الملف الكامل' ? node.t : f.t,
        subId: sub.id, subName: sub.name, subIcon: sub.icon,
        secName: secName, nodePath: path, nodeTitle: node.t,
        crumbs: crumb.concat([node.t])
      };
      if (!FILES.has(f.id)) {
        FILES.set(f.id, rec);
        ALL_IDS.push(f.id);
      }
      ids.push(f.id);
    });
    (node.c || []).forEach(function (child, i) {
      ids.push.apply(ids, walk(child, sub, secName, crumb.concat([node.t]), path + '.' + i));
    });
    node._ids = ids;
    return ids;
  }

  SUBJECTS.forEach(function (sub) {
    const ids = [];
    sub.sections.forEach(function (sec, i) {
      ids.push.apply(ids, walk(sec, sub, sec.t, [], String(i)));
    });
    sub._ids = Array.from(new Set(ids));
    sub._total = ids.length;
  });

  const TOTAL_FILES = SUBJECTS.reduce((a, s) => a + s._total, 0);
  const TOTAL_UNIQUE = ALL_IDS.length;

  /* ---------- helpers ---------- */
  function pct(a, b) { return b ? Math.round((a / b) * 100) : 0; }

  function pctTag(p) { return '<span dir="ltr">' + p + '%</span>'; }

  function subDone(sub) { return sub._ids.filter((id) => State.done.has(id)).length; }

  function overallDone() { return ALL_IDS.filter((id) => State.done.has(id)).length; }

  function getSubject(id) { return SUBJECTS.find((s) => s.id === id); }

  function findNode(sub, path) {
    if (!sub) return null;
    const parts = String(path).split('.').map(Number);
    if (!parts.length || parts.some(isNaN)) return null;
    const trail = [];
    let node = sub.sections[parts[0]];
    if (!node) return null;
    trail.push({ t: node.t, path: String(parts[0]) });
    for (let i = 1; i < parts.length; i++) {
      if (!node.c || !node.c[parts[i]]) return null;
      node = node.c[parts[i]];
      trail.push({ t: node.t, path: parts.slice(0, i + 1).join('.') });
    }
    return { node: node, trail: trail };
  }

  function sectionIcon(title) {
    const t = String(title);
    const map = [
      ['برنامج', '📅'], ['مكتسب', '🔁'], ['درس', '🎓'], ['ملخص', '📝'], ['مطوي', '📝'],
      ['تمرين', '✏️'], ['سلسل', '✏️'], ['فرض', '📋'], ['اختبار', '🧪'], ['موضوع', '🧪'],
      ['كتاب', '📚'], ['مقال', '✍️'], ['منهج', '🧭'], ['خرائط', '🗺️'], ['ذهني', '🧠'],
      ['قواعد', '📐'], ['محور', '📐'], ['شعر', '📖'], ['نثر', '📖'], ['قانون', '⚖️'],
      ['اقتصاد', '💹'], ['إحصاء', '📊'], ['احتمال', '🎲'], ['دوال', '📈'], ['متتالي', '🔢'],
      ['Gramm', '🔤'], ['Ethics', '💼'], ['Safety', '🦺'], ['Astronomy', '🌌'],
      ['compte', '🇫🇷'], ['ثمينة', '💎'], ['تميز', '🏆'], ['وضعيات', '🧩'], ['أحكام', '🕌'],
      ['تدريب', '🎯'], ['أفكار', '💡'], ['محفوظ', '🔖'], ['Le ', '🇫🇷'], ['فقرات', '🇬🇧']
    ];
    for (let i = 0; i < map.length; i++) if (t.indexOf(map[i][0]) !== -1) return map[i][1];
    return '📁';
  }

  const CHECK_SVG = '<svg viewBox="0 0 24 24"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>';
  const CHEV_SVG = '<svg class="chev" viewBox="0 0 24 24"><path d="M14 6l-6 6 6 6"/></svg>';

  function toast(msg) {
    const el = $('#toast');
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => el.classList.remove('show'), 1800);
  }

  /* ---------- countdown ---------- */
  function countdownVals() {
    const target = new Date(State.bacDate + 'T08:00:00+01:00').getTime();
    let diff = target - Date.now();
    if (isNaN(diff) || diff < 0) diff = 0;
    return {
      d: Math.floor(diff / 86400000),
      h: Math.floor(diff / 3600000) % 24,
      m: Math.floor(diff / 60000) % 60,
      s: Math.floor(diff / 1000) % 60
    };
  }

  function updateCountdown() {
    const els = $$('[data-cd]');
    if (!els.length) return;
    const v = countdownVals();
    els.forEach(function (el) {
      const key = el.dataset.cd;
      let n = v[key];
      if (key === 'd') n = String(n).padStart(3, '0');
      else n = String(n).padStart(2, '0');
      if (el.textContent !== n) el.textContent = n;
    });
  }

  function cdMarkup(attr) {
    return '<div class="countdown">' +
      '<div class="cd-cell"><b data-cd="d">000</b><span>يوم</span></div>' +
      '<div class="cd-cell"><b data-cd="h">00</b><span>ساعة</span></div>' +
      '<div class="cd-cell"><b data-cd="m">00</b><span>دقيقة</span></div>' +
      '<div class="cd-cell"><b data-cd="s">00</b><span>ثانية</span></div>' +
      '</div>';
  }

  /* ---------- routing ---------- */
  const SCREEN = $('#screen');
  const BACK = $('#backBtn');

  function view(html) {
    SCREEN.innerHTML = '<div class="view fade-in">' + html + '</div>';
    updateCountdown();
    updateTabs();
  }

  function routeInfo() {
    const raw = location.hash.replace(/^#\/?/, '');
    return raw.split('/').filter(Boolean).map(decodeURIComponent);
  }

  function updateTabs() {
    const h = location.hash || '#/';
    let tab = 'home';
    if (h.indexOf('#/subjects') === 0 || /^#\/(subject|node)\//.test(h)) tab = 'subjects';
    else if (h.indexOf('#/tools') === 0) tab = 'tools';
    else if (h.indexOf('#/courses') === 0) tab = 'courses';
    else if (h.indexOf('#/account') === 0) tab = 'account';
    $$('.tabbar a').forEach((a) => a.classList.toggle('active', a.dataset.tab === tab));
    const root = h === '' || h === '#/' || h === '#/subjects' || h === '#/favorites' || h === '#/tools' || h === '#/courses' || h === '#/account';
    BACK.hidden = root;
  }

  function renderRoute() {
    CTX.clear();
    const parts = routeInfo();
    if (!parts.length) return home();
    if (parts[0] === 'subjects') return subjectsPage();
    if (parts[0] === 'subject') return subjectPage(parts[1]);
    if (parts[0] === 'node') return nodePage(parts[1], parts[2]);
    if (parts[0] === 'favorites') return favoritesPage();
    if (parts[0] === 'tools') return toolsPage();
    if (parts[0] === 'courses') return coursesPage();
    if (parts[0] === 'account') return accountPage();
    if (parts[0] === 'search') return searchPage();
    location.replace('#/');
  }

  function go(hash) { location.hash = hash; }

  function onRoute() {
    renderRoute();
    window.scrollTo(0, 0);
  }

  /* ---------- home ---------- */
  function home() {
    const done = overallDone();
    const progress = pct(done, TOTAL_UNIQUE);
    const last = State.last && FILES.get(State.last.id) ? FILES.get(State.last.id) : null;

    const cards = SUBJECTS.map(function (s) {
      const p = pct(subDone(s), s._ids.length);
      return '<button class="subject-card" data-act="subject" data-id="' + esc(s.id) + '">' +
        '<div class="sc-top"><div class="sc-ico">' + s.icon + '</div>' +
        '<div><div class="sc-name">' + esc(s.name) + '</div><div class="sc-count">' + s._total + ' ملف · ' + pctTag(p) + '</div></div></div>' +
        '<div class="sc-bar"><i style="width:' + p + '%"></i></div>' +
        '</button>';
    }).join('');

    view(
      '<section class="hero">' +
        '<div class="hero-badge"><i></i> بكالوريا 2027 · شعبة التسيير والاقتصاد</div>' +
        '<h2>طريقك إلى<br><span>البكالوريا</span> يبدأ من هنا</h2>' +
        '<p class="hero-sub">كل مصادر شعبتك في مكان واحد: دروس، ملخصات، سلاسل تمارين، فروض ومواضيع مقترحة.</p>' +
        cdMarkup() +
        '<button class="hero-cta" data-act="' + (last ? 'file' : 'subjects') + '"' +
          (last ? ' data-id="' + esc(last.id) + '" data-ctx="' + ctx(last.subId ? [last.id] : []) + '"' : '') + '>' +
          '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7-11-7Z"/></svg>' +
          '<span>' + (last ? 'متابعة الدراسة' : 'ابدأ الآن') + '</span>' +
        '</button>' +
      '</section>' +
      '<div class="stats">' +
        '<div class="stat"><b>' + SUBJECTS.length + '</b><span>مادة دراسية</span></div>' +
        '<div class="stat"><b>' + TOTAL_FILES + '</b><span>ملف دراسي</span></div>' +
        '<div class="stat"><b>' + pctTag(progress) + '</b><span>تقدمك</span></div>' +
      '</div>' +
      (last ? '<div class="section-head"><h3>متابعة من حيث توقفت</h3></div>' +
        '<div class="list">' + fileRow(last, [last.id]) + '</div>' : '') +
      '<div class="quiz-card">' +
        '<div class="quiz-ic">🧠</div>' +
        '<div class="quiz-body"><strong>الكويز</strong><span>اختبر حفظك بأسئلة قصيرة بعد كل درس</span></div>' +
        '<span class="soon">قريباً</span>' +
      '</div>' +
      '<div class="section-head"><h3>أدوات المراجعة</h3><a href="#/tools">فتح <svg viewBox="0 0 24 24"><path d="M14 6l-6 6 6 6"/></svg></a></div>' +
      '<div class="list">' +
        '<div class="row" data-act="tools"><div class="row-ico">⏱️</div><div class="row-body"><div class="row-title">عداد البكالوريا</div><div class="row-sub">الوقت المتبقي حتى الامتحان</div></div>' + CHEV_SVG + '</div>' +
        '<div class="row" data-act="tools"><div class="row-ico">🧮</div><div class="row-body"><div class="row-title">حاسبة المعدل</div><div class="row-sub">احسب معدلك الفصلي أو التجريبي</div></div>' + CHEV_SVG + '</div>' +
        '<div class="row" data-act="tools"><div class="row-ico">🍅</div><div class="row-body"><div class="row-title">مؤقت المراجعة</div><div class="row-sub">تركيز 25 دقيقة ثم راحة قصيرة</div></div>' + CHEV_SVG + '</div>' +
      '</div>'
    );
  }

  /* ---------- rows ---------- */
  function fileRow(f, ids) {
    if (!f) return '';
    const done = State.done.has(f.id);
    const fav = State.favs.has(f.id);
    return '<div class="row ' + (done ? 'done' : '') + '" role="button" tabindex="0" data-act="file" data-id="' + esc(f.id) + '" data-ctx="' + ctx(ids) + '">' +
      '<div class="row-ico">📄</div>' +
      '<div class="row-body"><div class="row-title">' + esc(f.t) + '</div>' +
        '<div class="row-sub"><span>' + esc(f.subName) + '</span><span class="dot"></span><span>PDF</span>' +
        (fav ? '<span class="tag gold">محفوظ</span>' : '') + '</div></div>' +
      '<button class="tick ' + (done ? 'on' : '') + '" data-act="done" data-id="' + esc(f.id) + '" aria-label="تمت المراجعة">' + CHECK_SVG + '</button>' +
      '</div>';
  }

  function nodeRow(sub, node, path) {
    return '<div class="row" role="button" tabindex="0" data-act="node" data-sub="' + esc(sub.id) + '" data-path="' + esc(path) + '">' +
      '<div class="row-ico">' + sectionIcon(node.t) + '</div>' +
      '<div class="row-body"><div class="row-title">' + esc(node.t) + '</div>' +
      '<div class="row-sub"><span>' + (node.n || 0) + ' ملف</span>' + (node.c && node.c.length ? '<span class="dot"></span><span>' + node.c.length + ' قسم فرعي</span>' : '') + '</div></div>' +
      CHEV_SVG + '</div>';
  }

  const CTX = new Map();
  let ctxSeq = 0;
  function ctx(ids) {
    const k = 'x' + (++ctxSeq);
    CTX.set(k, ids.filter(Boolean));
    return k;
  }

  /* ---------- subjects ---------- */
  function subjectsPage() {
    const rows = SUBJECTS.map(function (s) {
      const p = pct(subDone(s), s._ids.length);
      return '<div class="row" role="button" tabindex="0" data-act="subject" data-id="' + esc(s.id) + '">' +
        '<div class="row-ico">' + s.icon + '</div>' +
        '<div class="row-body"><div class="row-title">' + esc(s.name) + '</div>' +
        '<div class="row-sub"><span>' + s._total + ' ملف</span><span class="dot"></span><span>' + pctTag(p) + ' مكتمل</span></div>' +
        '<div class="sc-bar" style="margin-top:7px"><i style="width:' + p + '%"></i></div></div>' +
        CHEV_SVG + '</div>';
    }).join('');

    view('<div class="page-title">مواد الشعبة</div>' +
      '<div class="page-sub">' + SUBJECTS.length + ' مادة · ' + TOTAL_FILES + ' ملف — اختر مادة للبدء</div>' +
      '<div class="search-box"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/></svg>' +
      '<input id="subjFilter" type="search" placeholder="ابحث عن مادة…" autocomplete="off"></div>' +
      '<div class="list" id="subjList">' + rows + '</div>');

    const input = $('#subjFilter');
    input.addEventListener('input', function () {
      const q = norm(input.value);
      $$('#subjList .row').forEach(function (r) {
        r.style.display = norm(r.textContent).indexOf(q) !== -1 ? '' : 'none';
      });
    });
  }

  /* ---------- subject ---------- */
  function subjectPage(id) {
    const sub = getSubject(id);
    if (!sub) { go('#/subjects'); return; }
    const done = subDone(sub);
    const p = pct(done, sub._ids.length);

    const sections = sub.sections.map(function (sec, i) {
      return nodeRow(sub, sec, String(i));
    }).join('');

    view(
      '<div class="subject-hero"><div class="sh-glow"></div>' +
        '<div class="sh-top"><div class="sh-ico">' + sub.icon + '</div>' +
          '<div><div class="sh-name">' + esc(sub.name) + '</div><div class="sh-desc">' + esc(sub.desc) + '</div></div></div>' +
        '<div class="sh-progress"><div class="lbl"><span>تقدمك في المادة</span><b>' + pctTag(p) + '</b></div>' +
          '<div class="bar"><i style="width:' + p + '%"></i></div></div>' +
        '<div class="sh-meta"><span class="chip">' + sub._total + ' ملف</span><span class="chip">' + sub.sections.length + ' أقسام</span>' +
          '<span class="chip">' + done + ' مكتمل</span></div>' +
      '</div>' +
      '<div class="section-head"><h3>الأقسام</h3></div>' +
      '<div class="list">' + sections + '</div>'
    );
  }

  /* ---------- node ---------- */
  function nodePage(subId, path) {
    const sub = getSubject(subId);
    const found = findNode(sub, path);
    if (!sub || !found) { go('#/subjects'); return; }
    const node = found.node;
    const ids = node._ids || [];
    const files = (node.f || []).map((f) => FILES.get(f.id)).filter(Boolean);

    const crumbs = '<div class="crumbs"><a href="#/subjects">المواد</a><span class="sep">/</span>' +
      '<a href="#/subject/' + esc(sub.id) + '">' + esc(sub.name) + '</a>' +
      found.trail.map(function (t, i) {
        const last = i === found.trail.length - 1;
        return '<span class="sep">/</span>' + (last ? '<span class="cur">' + esc(t.t) + '</span>'
          : '<a href="#/node/' + esc(sub.id) + '/' + esc(t.path) + '">' + esc(t.t) + '</a>');
      }).join('') + '</div>';

    const filesHtml = files.length ?
      '<div class="section-head"><h3>الملفات</h3><span class="chip">' + files.length + '</span></div>' +
      '<div class="list">' + files.map((f) => fileRow(f, files.map((x) => x.id))).join('') + '</div>' : '';

    const kids = (node.c || []).map(function (child, i) {
      return nodeRow(sub, child, path + '.' + i);
    }).join('');

    const kidsHtml = kids ? '<div class="section-head"><h3>أقسام فرعية</h3></div><div class="list">' + kids + '</div>' : '';

    const done = ids.filter((x) => State.done.has(x)).length;

    view(crumbs +
      '<div class="page-title">' + esc(node.t) + '</div>' +
      '<div class="page-sub">' + (ids.length ? done + ' من ' + ids.length + ' مكتمل · ' : '') + esc(sub.name) + '</div>' +
      filesHtml + kidsHtml);
  }

  /* ---------- search ---------- */
  let searchSubject = 'all';
  let searchQuery = '';

  function searchPage() {
    const chips = '<button class="filter-chip ' + (searchSubject === 'all' ? 'on' : '') + '" data-act="filter" data-id="all">الكل</button>' +
      SUBJECTS.map((s) => '<button class="filter-chip ' + (searchSubject === s.id ? 'on' : '') + '" data-act="filter" data-id="' + esc(s.id) + '">' + s.icon + ' ' + esc(s.name.split(' ')[0]) + '</button>').join('');

    view('<div class="page-title">البحث</div>' +
      '<div class="page-sub">ابحث في ' + TOTAL_UNIQUE + ' ملف داخل كل مواد الشعبة</div>' +
      '<div class="search-box"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/></svg>' +
      '<input id="searchInput" type="search" placeholder="مثال: الاهتلاكات، الميزانية، الاحتمالات…" autocomplete="off" enterkeyhint="search"></div>' +
      '<div class="filter-row">' + chips + '</div>' +
      '<div id="searchResults"></div>');

    const input = $('#searchInput');
    input.value = searchQuery;
    input.addEventListener('input', () => runSearch(input.value));
    runSearch(searchQuery);
  }

  function runSearch(q) {
    searchQuery = q;
    const box = $('#searchResults');
    if (!box) return;
    const nq = norm(q);
    if (!nq) {
      box.innerHTML = '<div class="hint"><span class="big">🔍</span>اكتب اسم الدرس أو الموضوع،<br>وستجد كل الملفات المتعلقة به.</div>';
      return;
    }
    const terms = nq.split(/\s+/).filter(Boolean);
    const hits = [];
    FILES.forEach(function (f) {
      if (searchSubject !== 'all' && f.subId !== searchSubject) return;
      const hay = norm(f.t + ' ' + f.subName + ' ' + f.secName + ' ' + f.nodeTitle + ' ' + (f.crumbs || []).join(' '));
      if (terms.every((t) => hay.indexOf(t) !== -1)) hits.push(f);
    });
    if (!hits.length) {
      box.innerHTML = '<div class="empty"><span class="big">😕</span><p>لا توجد نتائج مطابقة.<br>جرّب كلمة أقصر أو غيّر المادة.</p></div>';
      return;
    }
    const ids = hits.map((f) => f.id);
    box.innerHTML = '<div class="page-sub">' + hits.length + ' نتيجة</div><div class="list">' +
      hits.slice(0, 80).map((f) => fileRow(f, ids)).join('') + '</div>' +
      (hits.length > 80 ? '<div class="mini-note" style="text-align:center">تظهر أول 80 نتيجة، جرّب كلمة أدق.</div>' : '');
  }

  /* ---------- favorites ---------- */
  function favoritesPage() {
    const items = Array.from(State.favs).map((id) => FILES.get(id)).filter(Boolean);
    if (!items.length) {
      view('<div class="page-title">المحفوظات</div>' +
        '<div class="empty"><span class="big">🔖</span><p>لا ملفات محفوظة بعد.<br>اضغط أيقونة الحفظ داخل أي ملف للرجوع إليه لاحقاً.</p>' +
        '<div style="margin-top:16px"><a class="btn primary" href="#/subjects">تصفح المواد</a></div></div>');
      return;
    }
    const ids = items.map((f) => f.id);
    view('<div class="page-title">المحفوظات</div>' +
      '<div class="page-sub">' + items.length + ' ملف محفوظ</div>' +
      '<div class="list">' + items.map((f) => fileRow(f, ids)).join('') + '</div>');
  }

  /* ---------- courses ---------- */
  function coursesPage() {
    view('<div class="page-title">الدورات</div>' +
      '<div class="page-sub">دورات مراجعة وتدريب قصيرة</div>' +
      '<div class="empty"><span class="big">🎬</span><p>لا توجد دورات بعد.<br>ستُضاف الدورات هنا قريباً.</p></div>');
  }

  /* ---------- account ---------- */
  let accountEditing = false;

  function accountForm(p) {
    return '<div class="tool-card acc-card">' +
      '<div class="acc-profile"><div class="acc-avatar">' + (p ? esc(p.name.trim().charAt(0)) : '👤') + '</div>' +
        '<div class="acc-info"><strong>' + (p ? 'تعديل بيانات الحساب' : 'بيانات الطالب') + '</strong>' +
        '<span>' + (p ? 'حدّث اسمك ووسيلة التواصل' : 'اسمك ووسيلة تواصل واحدة') + '</span></div></div>' +
      '<div class="acc-field"><label for="accName">اسم الطالب أو الطالبة</label>' +
        '<input id="accName" type="text" autocomplete="name" value="' + esc(p ? p.name : '') + '" placeholder="الاسم الكامل"></div>' +
      '<div class="acc-field"><label for="accContact">البريد الإلكتروني أو رقم الهاتف</label>' +
        '<input id="accContact" type="text" autocomplete="email" dir="ltr" value="' + esc(p ? p.contact : '') + '" placeholder="example@mail.com / 06XXXXXXXX"></div>' +
      '<button class="btn primary acc-save" id="accSave">' + (p ? 'حفظ التعديلات' : 'إنشاء الحساب') + '</button>' +
      '<p class="mini-note">تُحفظ بياناتك على هذا الجهاز فقط ولا تُرسل إلى أي جهة.</p>' +
    '</div>';
  }

  function accountPage() {
    const p = State.profile;
    if (p && !accountEditing) {
      view('<div class="page-title">الحساب</div>' +
        '<div class="page-sub">ملفك الشخصي</div>' +
        '<div class="tool-card"><div class="acc-profile">' +
          '<div class="acc-avatar">' + esc(p.name.trim().charAt(0)) + '</div>' +
          '<div class="acc-info"><strong>' + esc(p.name) + '</strong><span dir="auto">' + esc(p.contact) + '</span></div>' +
        '</div>' +
        '<button class="btn acc-save" data-act="edit-account">تعديل البيانات</button>' +
        '</div>' +
        '<div class="mini-note" style="text-align:center">بياناتك محفوظة على هذا الجهاز فقط.</div>' +
        '<div class="dev-credit">المطور: <b>moha info</b></div>');
      return;
    }
    view('<div class="page-title">' + (p ? 'تعديل الحساب' : 'إنشاء حساب') + '</div>' +
      '<div class="page-sub">' + (p ? 'حدّث بياناتك ثم احفظ' : 'خطوة واحدة وتبدأ الدراسة') + '</div>' +
      accountForm(p) +
      '<div class="dev-credit">المطور: <b>moha info</b></div>');
    bindAccountForm();
  }

  function bindAccountForm() {
    const save = $('#accSave');
    const nameEl = $('#accName');
    const contactEl = $('#accContact');
    if (!save || !nameEl || !contactEl) return;
    const submit = function () {
      const name = nameEl.value.trim();
      const contact = contactEl.value.trim();
      if (name.length < 2) { toast('اكتب اسم الطالب أو الطالبة'); nameEl.focus(); return; }
      const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(contact);
      const isPhone = /^[+\d][\d\s\-()]{6,}$/.test(contact);
      if (!isEmail && !isPhone) { toast('أدخل بريداً إلكترونياً أو رقم هاتف صحيحاً'); contactEl.focus(); return; }
      State.profile = { name: name, contact: contact, ts: Date.now() };
      store.set('profile', State.profile);
      accountEditing = false;
      toast('تم إنشاء الحساب');
      go('#/');
    };
    save.addEventListener('click', submit);
    [nameEl, contactEl].forEach(function (el) {
      el.addEventListener('keydown', function (e) { if (e.key === 'Enter') submit(); });
    });
    if (!State.profile) setTimeout(function () { if (document.body.contains(nameEl)) nameEl.focus(); }, 300);
  }

  /* ---------- tools ---------- */
  let pomo = { left: 25 * 60, total: 25 * 60, running: false, mode: 'focus', sessions: 0, timer: null };

  function toolsPage() {
    const standing = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone;

    const calcRows = SUBJECTS.map(function (s) {
      const c = State.coeffs[s.id] != null ? State.coeffs[s.id] : (DEFAULT_COEFF[s.id] || 0);
      const m = State.marks[s.id] != null ? State.marks[s.id] : '';
      return '<div class="calc-row" data-sub="' + esc(s.id) + '">' +
        '<span>' + esc(s.name) + '</span>' +
        '<input type="number" min="0" max="20" step="0.25" inputmode="decimal" placeholder="—" data-role="mark" value="' + esc(m) + '">' +
        '<input type="number" min="0" max="10" step="1" inputmode="numeric" data-role="coef" value="' + c + '">' +
        '</div>';
    }).join('');

    view(
      '<div class="tool-card">' +
        '<div class="tool-head"><div class="ti">⏱️</div><div><h3>عداد البكالوريا</h3><p>الوقت المتبقي حتى موعد الامتحان</p></div></div>' +
        '<div class="cd-big">' +
          '<div><b data-cd="d">000</b><span>يوم</span></div>' +
          '<div><b data-cd="h">00</b><span>ساعة</span></div>' +
          '<div><b data-cd="m">00</b><span>دقيقة</span></div>' +
          '<div><b data-cd="s">00</b><span>ثانية</span></div>' +
        '</div>' +
        '<div class="field"><label>تاريخ البكالوريا</label><input type="date" id="bacDateInput" value="' + esc(State.bacDate) + '"></div>' +
        '<div class="mini-note">التاريخ قابل للتعديل حسب الرزنامة الرسمية.</div>' +
      '</div>' +

      '<div class="tool-card">' +
        '<div class="tool-head"><div class="ti">🧮</div><div><h3>حاسبة المعدل</h3><p>أدخل نقاطك ومعاملات مواد الشعبة</p></div></div>' +
        '<div class="calc-table">' + calcRows + '</div>' +
        '<div class="calc-out"><div><div class="big" id="avgOut">—</div><span>المعدل المرجح</span></div>' +
          '<button class="btn ghost" data-act="reset-calc">تصفير</button></div>' +
        '<div class="mini-note">المعاملات الافتراضية تقديرية — عدّلها حسب ما يظهر في كشف نقاطك.</div>' +
      '</div>' +

      '<div class="tool-card">' +
        '<div class="tool-head"><div class="ti">🍅</div><div><h3>مؤقت المراجعة</h3><p>تركيز كامل لـ 25 دقيقة ثم راحة</p></div></div>' +
        '<div class="pomo">' +
          '<div class="pomo-ring"><svg viewBox="0 0 168 168">' +
            '<circle class="track" cx="84" cy="84" r="76"></circle>' +
            '<circle class="prog" id="pomoProg" cx="84" cy="84" r="76" stroke-dasharray="477.5" stroke-dashoffset="0"></circle>' +
          '</svg><div class="pomo-time"><b id="pomoTime">25:00</b><span id="pomoLabel">وقت المراجعة</span></div></div>' +
          '<div class="btns">' +
            '<button class="btn primary" data-act="pomo-toggle" id="pomoToggle">▶ بدء</button>' +
            '<button class="btn ghost" data-act="pomo-reset">إعادة</button>' +
          '</div>' +
          '<div class="mini-note">جلسات مكتملة اليوم: <b id="pomoCount">0</b></div>' +
        '</div>' +
      '</div>' +

      (!standing ? '<div class="tool-card"><div class="tool-head"><div class="ti">📲</div><div><h3>تثبيت التطبيق</h3><p>استعمله بدون متصفح من الشاشة الرئيسية</p></div></div>' +
        '<button class="btn primary" data-act="install" id="installBtn" style="width:100%;justify-content:center">إضافة إلى الشاشة الرئيسية</button>' +
        '<div class="mini-note" id="installNote">على أندرويد: قائمة المتصفح ← «إضافة إلى الشاشة الرئيسية». الملفات تحتاج اتصالاً بالإنترنت.</div></div>' : '') +

      '<div class="tool-card"><div class="tool-head"><div class="ti">ℹ️</div><div><h3>حول التطبيق</h3><p>نسخة 1.7</p></div></div>' +
        '<div class="mini-note">تطبيق مجاني يجمع مصادر شعبة التسيير والاقتصاد في واجهة سريعة. ' +
        'يعمل بدون إنترنت لتصفح الفهرس، أما فتح الملفات فيحتاج اتصالاً.</div>' +
        '<a class="tg-row" href="https://t.me/mohateam2026" target="_blank" rel="noopener">' +
          '<span>قناة التيليغرام للمزيد من المعلومات</span><b>@mohateam2026</b></a>' +
        '<div class="dev-credit">المطور: <b>moha info</b></div></div>'
    );

    const dateInput = $('#bacDateInput');
    if (dateInput) dateInput.addEventListener('change', function () {
      if (dateInput.value) {
        State.bacDate = dateInput.value;
        store.set('date', State.bacDate);
        updateCountdown();
        toast('تم تحديث تاريخ البكالوريا');
      }
    });

    $$('#screen .calc-row').forEach(function (row) {
      row.addEventListener('input', function () {
        const sid = row.dataset.sub;
        const mark = row.querySelector('[data-role=mark]');
        const coef = row.querySelector('[data-role=coef]');
        let m = parseFloat(mark.value);
        if (isNaN(m)) delete State.marks[sid];
        else State.marks[sid] = Math.min(20, Math.max(0, m));
        let c = parseFloat(coef.value);
        if (isNaN(c)) c = 0;
        State.coeffs[sid] = Math.min(10, Math.max(0, c));
        store.set('marks', State.marks);
        store.set('coeffs', State.coeffs);
        computeAverage();
      });
    });
    computeAverage();
    renderPomo();
  }

  function computeAverage() {
    let sum = 0, w = 0;
    SUBJECTS.forEach(function (s) {
      const m = State.marks[s.id];
      const c = State.coeffs[s.id] != null ? Number(State.coeffs[s.id]) : 0;
      if (m != null && c > 0) { sum += m * c; w += c; }
    });
    const out = $('#avgOut');
    if (!out) return;
    out.textContent = w ? (sum / w).toFixed(2) + ' / 20' : '—';
  }

  function renderPomo() {
    const t = $('#pomoTime');
    if (!t) return;
    const m = Math.floor(pomo.left / 60), s = pomo.left % 60;
    t.textContent = String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
    const prog = $('#pomoProg');
    if (prog) prog.style.strokeDashoffset = String(477.5 * (1 - pomo.left / pomo.total));
    const lbl = $('#pomoLabel');
    if (lbl) lbl.textContent = pomo.mode === 'focus' ? 'وقت المراجعة' : 'وقت الراحة';
    const btn = $('#pomoToggle');
    if (btn) btn.textContent = pomo.running ? '❚❚ إيقاف مؤقت' : '▶ بدء';
    const cnt = $('#pomoCount');
    if (cnt) cnt.textContent = pomo.sessions;
    const ring = prog;
    if (ring) ring.style.stroke = pomo.mode === 'focus' ? 'var(--brand)' : 'var(--gold)';
  }

  function pomoTick() {
    if (!pomo.running) return;
    pomo.left--;
    if (pomo.left <= 0) {
      pomo.running = false;
      if (pomo.mode === 'focus') {
        pomo.sessions++;
        pomo.mode = 'break';
        pomo.total = 5 * 60;
        toast('أحسنت! خذ راحة 5 دقائق');
      } else {
        pomo.mode = 'focus';
        pomo.total = 25 * 60;
        toast('انتهت الراحة، لنعد إلى المراجعة');
      }
      pomo.left = pomo.total;
    }
    renderPomo();
  }

  /* ---------- viewer ---------- */
  const VIEWER = $('#viewer');
  const FRAME = $('#pdfFrame');
  const LOADING = $('#viewerLoading');

  function openFile(id, list) {
    const f = FILES.get(id);
    if (!f) return;
    const ids = (list && list.length) ? list.filter((x) => FILES.has(x)) : [id];
    if (ids.indexOf(id) === -1) ids.unshift(id);
    State.viewer = { id: id, list: ids, index: ids.indexOf(id) };
    State.last = { id: id, ts: Date.now() };
    store.set('last', State.last);
    VIEWER.hidden = false;
    VIEWER.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    paintViewer();
    if (!navigator.onLine) toast('لا يوجد اتصال — الملف يحتاج إنترنت');
  }

  function paintViewer() {
    if (!State.viewer) return;
    const v = State.viewer;
    const f = FILES.get(v.id);
    if (!f) return;
    $('#viewerTitle').textContent = f.t;
    $('#viewerTitle').title = f.t;
    LOADING.style.display = 'flex';
    clearTimeout(paintViewer._t);
    paintViewer._t = setTimeout(function () { LOADING.style.display = 'none'; }, 4000);
    FRAME.src = DRIVE + f.id + '/preview';
    $('#downloadBtn').href = DRIVE_DL + f.id;
    const done = State.done.has(f.id);
    const fav = State.favs.has(f.id);
    const db = $('#doneBtn');
    db.classList.toggle('on', done);
    db.querySelector('span').textContent = done ? 'تمت المراجعة' : 'تمت المراجعة';
    $('#favBtn').classList.toggle('on', fav);
    $('#favBtn').querySelector('span').textContent = fav ? 'محفوظ' : 'حفظ';
    $('#prevBtn').disabled = v.index <= 0;
    $('#nextBtn').disabled = v.index >= v.list.length - 1;
  }

  function closeViewer() {
    VIEWER.hidden = true;
    VIEWER.setAttribute('aria-hidden', 'true');
    FRAME.src = 'about:blank';
    document.body.style.overflow = '';
    State.viewer = null;
  }

  function stepViewer(dir) {
    if (!State.viewer) return;
    const v = State.viewer;
    const ni = v.index + dir;
    if (ni < 0 || ni >= v.list.length) return;
    v.index = ni;
    v.id = v.list[ni];
    const f = FILES.get(v.id);
    if (f) { State.last = { id: f.id, ts: Date.now() }; store.set('last', State.last); }
    paintViewer();
  }

  function toggleDone(id) {
    if (State.done.has(id)) State.done.delete(id); else State.done.add(id);
    store.set('done', Array.from(State.done));
    refreshAfterAction();
    if (State.viewer && State.viewer.id === id) paintViewer();
    toast(State.done.has(id) ? 'أُضيف إلى المكتمل ✓' : 'أُزيل من المكتمل');
  }

  function toggleFav(id) {
    if (State.favs.has(id)) State.favs.delete(id); else State.favs.add(id);
    store.set('favs', Array.from(State.favs));
    refreshAfterAction();
    if (State.viewer && State.viewer.id === id) paintViewer();
    toast(State.favs.has(id) ? 'أُضيف إلى المحفوظات 🔖' : 'أُزيل من المحفوظات');
  }

  function refreshAfterAction() {
    const y = window.scrollY;
    renderRoute();
    window.scrollTo(0, y);
  }

  /* ---------- global events ---------- */
  document.addEventListener('click', function (e) {
    const el = e.target.closest('[data-act]');
    if (!el) return;
    const act = el.dataset.act;
    if (act === 'theme') {
      State.theme = State.theme === 'dark' ? 'light' : 'dark';
      document.documentElement.dataset.theme = State.theme;
      store.set('theme', State.theme);
      const m = document.querySelector('meta[name=theme-color]');
      if (m) m.content = State.theme === 'dark' ? '#070d17' : '#f4f7fb';
      return;
    }
    if (act === 'home') { go('#/'); return; }
    if (act === 'search') {
      go('#/search');
      setTimeout(function () { const i = $('#searchInput'); if (i) i.focus(); }, 140);
      return;
    }
    if (act === 'subjects') { go('#/subjects'); return; }
    if (act === 'tools') { go('#/tools'); return; }
    if (act === 'subject') { go('#/subject/' + encodeURIComponent(el.dataset.id)); return; }
    if (act === 'node') { go('#/node/' + encodeURIComponent(el.dataset.sub) + '/' + el.dataset.path); return; }
    if (act === 'file') { openFile(el.dataset.id, CTX.get(el.dataset.ctx)); return; }
    if (act === 'done') { e.stopPropagation(); toggleDone(el.dataset.id); return; }
    if (act === 'close-viewer') { closeViewer(); return; }
    if (act === 'viewer-done') { if (State.viewer) toggleDone(State.viewer.id); return; }
    if (act === 'viewer-fav') { if (State.viewer) toggleFav(State.viewer.id); return; }
    if (act === 'filter') {
      searchSubject = el.dataset.id;
      renderRoute();
      return;
    }
    if (act === 'pomo-toggle') {
      pomo.running = !pomo.running;
      renderPomo();
      return;
    }
    if (act === 'pomo-reset') {
      pomo.running = false;
      pomo.mode = 'focus';
      pomo.total = 25 * 60;
      pomo.left = pomo.total;
      renderPomo();
      return;
    }
    if (act === 'reset-calc') {
      State.marks = {};
      State.coeffs = Object.assign({}, DEFAULT_COEFF);
      store.set('marks', {});
      store.set('coeffs', State.coeffs);
      renderRoute();
      toast('تم تصفير الحاسبة');
      return;
    }
    if (act === 'edit-account') { accountEditing = true; renderRoute(); return; }
    if (act === 'install') { installApp(); return; }
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && State.viewer) closeViewer();
    if (e.key === 'Enter' || e.key === ' ') {
      const el = document.activeElement;
      if (el && el.getAttribute('role') === 'button' && el.dataset.act) {
        e.preventDefault();
        el.click();
      }
    }
  });

  $('#prevBtn').addEventListener('click', () => stepViewer(-1));
  $('#nextBtn').addEventListener('click', () => stepViewer(1));
  FRAME.addEventListener('load', function () {
    if (FRAME.src && FRAME.src !== 'about:blank') LOADING.style.display = 'none';
  });

  $('#backBtn').addEventListener('click', function () {
    if (history.length > 1) history.back();
    else go('#/');
  });

  window.addEventListener('hashchange', onRoute);

  setInterval(updateCountdown, 1000);
  setInterval(pomoTick, 1000);

  /* ---------- install + SW ---------- */
  let deferredPrompt = null;
  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
    deferredPrompt = e;
  });

  function installApp() {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      deferredPrompt.userChoice.then(function () { deferredPrompt = null; });
    } else {
      toast('افتح قائمة المتصفح واختر «إضافة إلى الشاشة الرئيسية»');
    }
  }

  if ('serviceWorker' in navigator && location.protocol.indexOf('http') === 0) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('sw.js').catch(function () {});
    });
  }

  /* ---------- telegram notice ---------- */
  function initTgNotice() {
    const n = $('#tgNotice');
    if (!n) return;
    let hideT;
    const hide = function () {
      n.classList.remove('show');
      clearTimeout(hideT);
    };
    const x = $('#tgClose');
    if (x) x.addEventListener('click', hide);
    const goLink = n.querySelector('.tg-go');
    if (goLink) goLink.addEventListener('click', hide);
    const show = function () {
      if (n.classList.contains('show')) return;
      n.classList.add('show');
      clearTimeout(hideT);
      hideT = setTimeout(hide, 14000);
    };
    setTimeout(show, 500);
    setInterval(show, 5 * 60 * 1000);
  }

  /* ---------- splash ---------- */
  function initSplash() {
    const sp = $('#splash');
    if (!sp) { initTgNotice(); return; }
    let closed = false;
    const close = function () {
      if (closed) return;
      closed = true;
      sp.classList.add('hide');
      document.body.classList.remove('splash-open');
      setTimeout(function () {
        sp.remove();
        initTgNotice();
        if (!State.profile) go('#/account');
      }, 800);
    };
    document.body.classList.add('splash-open');
    sp.addEventListener('click', close);
    window.addEventListener('keydown', close, { once: true });
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    setTimeout(close, reduced ? 1200 : 2600);
  }

  /* ---------- start ---------- */
  document.documentElement.dataset.theme = State.theme === 'light' ? 'light' : 'dark';
  if (!location.hash) history.replaceState(null, '', '#/');
  initSplash();
  onRoute();
})();
